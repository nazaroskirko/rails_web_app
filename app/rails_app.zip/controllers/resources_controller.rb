class ResourcesController < ApplicationController
  # before_action :logged_in_user

    def create
    end

    def destroy
    end
end
