class InvoicesController < ApplicationController
  def index
  end
end
