class Buttercms::BaseController < ActionController::Base
  # You can of course change this layout to your main application layout
  # to have your blog match the rest of your site.
  layout 'application'
end
