class MarketplacesController < ApplicationController
  def index
  end
end
