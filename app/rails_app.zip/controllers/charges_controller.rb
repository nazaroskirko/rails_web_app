class ChargesController < ApplicationController
end
