class Conversation < ApplicationRecord

end
