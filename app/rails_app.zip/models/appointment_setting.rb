class AppointmentSetting < ApplicationRecord
  belongs_to :user
end
