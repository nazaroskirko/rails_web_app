class Day < ApplicationRecord
  belongs_to :user
end
