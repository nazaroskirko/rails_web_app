class Charge


  def initialize(appointment, *args)

  end


end
