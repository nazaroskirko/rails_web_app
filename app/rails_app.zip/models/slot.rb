class Slot < ApplicationRecord
end
