class BankAccount < ApplicationRecord
  belongs_to :user
end
