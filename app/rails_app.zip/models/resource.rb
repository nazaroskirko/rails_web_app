class Resource < ApplicationRecord
end
