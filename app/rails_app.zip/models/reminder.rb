class Reminder < ApplicationRecord

end
