class Dashboard < ApplicationRecord

  def initialize user
		@user = user
	end
end
